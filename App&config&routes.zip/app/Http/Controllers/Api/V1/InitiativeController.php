<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\V1\Concerns\ResolvesTenant;
use App\Http\Controllers\Controller;
use App\Models\ExecutionPlanTask;
use App\Models\Initiative;
use App\Models\Kpi;
use App\Models\ProgressUpdate;
use App\Models\Project;
use App\Models\User;
use App\Services\AccessScope;
use App\Services\ProgressRollup;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

/**
 * Initiatives (linked to projects and KPIs), their execution plan tasks, monthly progress and the performance data.
 * The models have no tenant scope, so every query filters on company_id explicitly.
 */
class InitiativeController extends Controller
{
    use ResolvesTenant;

    private const STATUSES = ['not_started', 'in_progress', 'completed', 'delayed', 'cancelled'];
    private const WITH     = ['department:id,name,name_ar', 'objective:id,code,name,name_ar', 'owner:id,name', 'tasks.assignee:id,name'];

    public function __construct(private ProgressRollup $rollup, private AccessScope $access) {}

    public function index(Request $request)
    {
        $request->validate([
            'year' => ['nullable', 'integer'], 'department_id' => ['nullable', 'integer'], 'strategic_objective_id' => ['nullable', 'integer'],
            'project_id' => ['nullable', 'integer'], 'status' => ['nullable', Rule::in(self::STATUSES)],
        ]);

        $rows = $this->access->scopeInitiatives(Initiative::with(self::WITH)->where('company_id', $this->companyId($request)), $request->user())
            ->when($request->filled('year'), fn ($q) => $q->where('year', $request->integer('year')))
            ->when($request->filled('department_id'), fn ($q) => $q->where('department_id', $request->integer('department_id')))
            ->when($request->filled('strategic_objective_id'), fn ($q) => $q->where('strategic_objective_id', $request->integer('strategic_objective_id')))
            ->when($request->filled('project_id'), fn ($q) => $q->whereIn('id', DB::table('initiative_project')->where('project_id', $request->integer('project_id'))->select('initiative_id')))
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->input('status')))
            ->orderBy('code')->orderBy('id')->limit(500)->get();

        return response()->json(['data' => $this->shapeMany($rows)]);
    }

    public function show(Request $request, int $id)
    {
        return response()->json(['data' => $this->shapeMany(collect([$this->find($request, $id)]))[0]]);
    }

    public function store(Request $request)
    {
        $this->authorizeWrite($request);
        $cid  = $this->companyId($request);
        $data = $request->validate($this->rules($cid));
        $this->guard($request, $data['department_id'] ?? null);
        [$projectIds, $kpiIds] = $this->links($request, $data);
        [$projectIds, $kpiIds] = $this->checkedLinks($request->user(), null, $projectIds, $kpiIds);

        $i = new Initiative();
        DB::transaction(function () use ($i, $data, $cid, $request, $projectIds, $kpiIds) {
            $i->forceFill(array_merge($data, ['company_id' => $cid, 'owner_id' => $data['owner_id'] ?? $request->user()->id]))->save();
            $this->syncLinks($i, $projectIds ?? [], $kpiIds ?? []);
        });
        $this->rollup->projects($projectIds ?? []);

        return response()->json(['data' => $this->shapeMany(collect([$i->load(self::WITH)]))[0]], 201);
    }

    public function update(Request $request, int $id)
    {
        $this->authorizeWrite($request);
        $i    = $this->find($request, $id);
        $this->guard($request, $i->department_id);
        $data = $request->validate($this->rules($i->company_id));
        if (array_key_exists('department_id', $data)) $this->guard($request, $data['department_id']);
        [$projectIds, $kpiIds] = $this->links($request, $data);
        [$projectIds, $kpiIds] = $this->checkedLinks($request->user(), $i, $projectIds, $kpiIds);
        $before = DB::table('initiative_project')->where('initiative_id', $i->id)->pluck('project_id')->all();

        DB::transaction(function () use ($i, $data, $projectIds, $kpiIds) {
            $i->forceFill($data)->save();
            $this->syncLinks($i, $projectIds, $kpiIds);
        });
        $this->rollup->projects(array_unique(array_merge($before, $projectIds ?? [])));

        return response()->json(['data' => $this->shapeMany(collect([$i->fresh(self::WITH)]))[0]]);
    }

    public function destroy(Request $request, int $id)
    {
        $this->authorizeWrite($request);
        $i      = $this->find($request, $id);
        $this->guard($request, $i->department_id);
        $linked = DB::table('initiative_project')->where('initiative_id', $i->id)->pluck('project_id')->all();

        DB::transaction(function () use ($i) {
            ProgressUpdate::where('subject_type', 'initiative')->where('subject_id', $i->id)->delete();
            $i->delete(); // tasks and links cascade
        });
        $this->rollup->projects($linked);

        return response()->noContent();
    }

    /** Report an initiative's completion for one month (admins/managers of its department, or the owner). Overrides the automatic value for that month. */
    public function progress(Request $request, int $id)
    {
        $i = $this->find($request, $id);
        $u = $request->user();
        abort_unless($this->access->canWorkOn($u, $i->department_id, $i->owner_id), 403, 'You do not have permission to update this initiative.');

        $data = $request->validate([
            'year' => ['required', 'integer', 'between:2000,2100'], 'month' => ['required', 'integer', 'between:1,12'],
            'completion_pct' => ['required', 'numeric', 'between:0,100'], 'note' => ['nullable', 'string'],
        ]);

        DB::transaction(function () use ($i, $data, $u) {
            ProgressUpdate::updateOrCreate(
                ['subject_type' => 'initiative', 'subject_id' => $i->id, 'year' => $data['year'], 'month' => $data['month']],
                ['company_id' => $i->company_id, 'completion_pct' => $data['completion_pct'], 'note' => $data['note'] ?? null, 'source' => 'manual', 'updated_by' => $u->id]
            );
            $this->rollup->applyLatest('initiative', $i);
        });
        $this->rollup->projectsOfInitiative($i->id);

        return response()->json(['data' => $this->shapeMany(collect([$i->fresh(self::WITH)]))[0]]);
    }

    /* ---- Execution plan tasks ---- */

    public function storeTask(Request $request, int $id)
    {
        $i = $this->find($request, $id);
        $this->authorizeTask($request, $i);
        $data = $request->validate($this->taskRules($i->company_id));
        $this->checkAssignee($i->company_id, $data);

        $t = new ExecutionPlanTask();
        $t->forceFill(array_merge($data, [
            'initiative_id' => $i->id, 'company_id' => $i->company_id, 'status' => $this->taskStatus((float) $data['completion_pct']),
            'sort_order' => (int) ExecutionPlanTask::where('initiative_id', $i->id)->max('sort_order') + 1,
        ]))->save();
        $this->rollup->initiative($i);

        return response()->json(['data' => $this->shapeMany(collect([$i->fresh(self::WITH)]))[0]], 201);
    }

    /**
     * Admins/managers of the department and the initiative's owner change everything on a task.
     * The person a task is assigned to (never a read-only viewer) may report the task's completion and nothing else.
     */
    public function updateTask(Request $request, int $id)
    {
        $t = $this->findTask($request, $id);
        $u = $request->user();
        $i = $t->initiative;

        if ($this->access->canWorkOn($u, $i->department_id, $i->owner_id)) {
            $data = $request->validate($this->taskRules($i->company_id));
            $this->checkAssignee($i->company_id, $data, $t);
        } else {
            abort_unless($this->isAssignee($u, $t), 403, 'You do not have permission to change this task.');
            $data = $request->validate(['completion_pct' => ['required', 'numeric', 'between:0,100']]);
        }

        $t->forceFill($data + ['status' => $this->taskStatus((float) $data['completion_pct'])])->save();
        $this->rollup->initiative($i);

        return response()->json(['data' => $this->shapeMany(collect([$i->fresh(self::WITH)]))[0]]);
    }

    public function destroyTask(Request $request, int $id)
    {
        $t = $this->findTask($request, $id);
        $i = $t->initiative;
        $this->authorizeTask($request, $i);
        $t->delete();
        $this->rollup->initiative($i);

        return response()->noContent();
    }

    /** GET /dashboard/initiatives?year=&month=&department_id= — same shape as /dashboard/projects. */
    public function performance(Request $request)
    {
        $request->validate(['year' => ['nullable', 'integer', 'between:2000,2100'], 'month' => ['nullable', 'integer', 'between:1,12'], 'department_id' => ['nullable', 'integer']]);
        $cid  = $this->companyId($request);
        $year = $request->integer('year') ?: (int) Initiative::where('company_id', $cid)->max('year') ?: (int) date('Y');

        $items = $this->access->scopeInitiatives(Initiative::with('department:id,name,name_ar')->where('company_id', $cid)->where('year', $year), $request->user())
            ->when($request->filled('department_id'), fn ($q) => $q->where('department_id', $request->integer('department_id')))
            ->orderBy('code')->orderBy('id')->get();

        $base    = ProgressUpdate::where('company_id', $cid)->where('subject_type', 'initiative')->where('year', $year);
        $updates = (clone $base)->whereIn('subject_id', $items->pluck('id'))->get()->groupBy('subject_id');
        $month   = $request->integer('month') ?: (int) (clone $base)->max('month') ?: (int) date('n');

        $carry = fn (array $s, int $m) => collect(array_slice($s, 0, $m))->filter(fn ($v) => $v !== null)->last();

        $rows = $items->map(function ($i) use ($updates, $month, $carry) {
            $by     = ($updates[$i->id] ?? collect())->keyBy('month');
            $series = array_map(fn ($m) => isset($by[$m]) ? (float) $by[$m]->completion_pct : null, range(1, 12));

            return [
                'id' => $i->id, 'code' => $i->code, 'name' => $i->name, 'name_ar' => $i->name_ar,
                'department' => $i->department?->only(['id', 'name', 'name_ar']),
                'status' => $i->status, 'is_on_timeline' => (bool) $i->is_on_timeline,
                'month_pct' => $carry($series, $month), 'series' => $series,
            ];
        })->values();

        $avg   = fn ($vals) => ($v = collect($vals)->filter(fn ($x) => $x !== null))->isEmpty() ? null : round($v->avg(), 2);
        $trend = array_map(fn ($m) => $avg($rows->map(fn ($r) => $carry($r['series'], $m))), range(1, 12));

        return response()->json(['data' => [
            'period' => ['year' => $year, 'month' => $month],
            'overall' => ['month' => $trend[$month - 1], 'ytd' => $avg(array_slice($trend, 0, $month))],
            'trend' => $trend, 'initiatives' => $rows,
        ]]);
    }

    /* ---- helpers ---- */

    private function rules(int $cid): array
    {
        $in = fn ($table) => Rule::exists($table, 'id')->where('company_id', $cid);

        return [
            'code' => ['nullable', 'string', 'max:255'], 'name' => ['required', 'string', 'max:255'], 'name_ar' => ['nullable', 'string', 'max:255'],
            'description' => ['nullable', 'string'], 'description_ar' => ['nullable', 'string'],
            'status' => ['required', Rule::in(self::STATUSES)], 'is_on_timeline' => ['required', 'boolean'],
            'planned_start_date' => ['nullable', 'date'], 'planned_end_date' => ['nullable', 'date', 'after_or_equal:planned_start_date'],
            'strategic_objective_id' => ['nullable', 'integer', $in('strategic_objectives')],
            'department_id' => ['nullable', 'integer', $in('departments')],
            'owner_id' => ['nullable', 'integer', $in('users')],
            'year' => ['required', 'integer', 'between:2000,2100'],
            'project_ids' => ['nullable', 'array'], 'project_ids.*' => ['integer', 'distinct', $in('projects')],
            'kpi_ids' => ['nullable', 'array'], 'kpi_ids.*' => ['integer', 'distinct', $in('kpis')],
        ];
    }

    private function taskRules(int $cid): array
    {
        return [
            'task_name' => ['required', 'string', 'max:255'], 'task_name_ar' => ['nullable', 'string', 'max:255'],
            'due_date' => ['nullable', 'date'], 'completion_pct' => ['required', 'numeric', 'between:0,100'],
            'assigned_to' => ['sometimes', 'nullable', 'integer', Rule::exists('users', 'id')->where('company_id', $cid)],
        ];
    }

    /** A task can only be given to an active person of the company (keeping a person who was deactivated later is fine). */
    private function checkAssignee(int $cid, array $data, ?ExecutionPlanTask $task = null): void
    {
        if (empty($data['assigned_to'])) return;
        if ($task && (int) $task->assigned_to === (int) $data['assigned_to']) return;

        abort_unless(User::where('company_id', $cid)->where('is_active', true)->where('is_super_admin', false)->whereKey($data['assigned_to'])->exists(), 422, 'Tasks can only be assigned to active members of the company.');
    }

    private function taskStatus(float $pct): string
    {
        return $pct >= 100 ? 'completed' : ($pct > 0 ? 'in_progress' : 'pending');
    }

    /** Pull project_ids / kpi_ids out of the validated data. null = not sent (leave the links alone). */
    private function links(Request $request, array &$data): array
    {
        $projects = $request->has('project_ids') ? array_values($data['project_ids'] ?? []) : null;
        $kpis     = $request->has('kpi_ids') ? array_values($data['kpi_ids'] ?? []) : null;
        unset($data['project_ids'], $data['kpi_ids']);

        return [$projects, $kpis];
    }

    private function syncLinks(Initiative $i, ?array $projectIds, ?array $kpiIds): void
    {
        $now = now();
        foreach ([['initiative_project', 'project_id', $projectIds], ['initiative_kpi', 'kpi_id', $kpiIds]] as [$table, $col, $ids]) {
            if ($ids === null) {
                continue;
            }
            DB::table($table)->where('initiative_id', $i->id)->delete();
            DB::table($table)->insert(array_map(fn ($id) => ['initiative_id' => $i->id, $col => $id, 'created_at' => $now, 'updated_at' => $now], $ids));
        }
    }

    /** An initiative the user may not see is a 404, the same as another company's. */
    private function find(Request $request, int $id): Initiative
    {
        $i = Initiative::with(self::WITH)->where('company_id', $this->companyId($request))->findOrFail($id);
        abort_unless($this->access->canSeeInitiative($request->user(), $i), 404);

        return $i;
    }

    private function findTask(Request $request, int $id): ExecutionPlanTask
    {
        $t = ExecutionPlanTask::with('initiative')->where('company_id', $this->companyId($request))->findOrFail($id);
        abort_unless($t->initiative && $this->access->canSeeInitiative($request->user(), $t->initiative), 404);

        return $t;
    }

    /** Changing an initiative needs the admin/manager role in its department (no department: unrestricted editors only). */
    private function guard(Request $request, $departmentId): void
    {
        abort_unless(
            $this->access->canManage($request->user(), $departmentId === null ? null : (int) $departmentId),
            403, 'You can only manage initiatives in your own departments.'
        );
    }

    /**
     * Links may only point at projects and KPIs the user can see. Links the user cannot see are not shown to them,
     * so on an update they are kept as they are rather than dropped. null = the key was not sent (leave links alone).
     */
    private function checkedLinks(User $u, ?Initiative $i, ?array $projectIds, ?array $kpiIds): array
    {
        $cid = (int) $u->company_id;

        if ($projectIds !== null) {
            $visible = $this->access->scopeVisible(Project::where('company_id', $cid)->whereIn('id', $projectIds), $u)->pluck('id')->all();
            abort_if(count(array_diff($projectIds, $visible)) > 0, 422, 'You can only link projects you can see.');
            if ($i) {
                $current = DB::table('initiative_project')->where('initiative_id', $i->id)->pluck('project_id')->all();
                $seen    = $this->access->scopeVisible(Project::where('company_id', $cid)->whereIn('id', $current), $u)->pluck('id')->all();
                $projectIds = array_values(array_unique(array_merge($projectIds, array_diff($current, $seen))));
            }
        }

        if ($kpiIds !== null) {
            $visible = $this->access->scopeByDepartment(Kpi::withoutGlobalScopes()->where('company_id', $cid)->whereIn('id', $kpiIds), $u)->pluck('id')->all();
            abort_if(count(array_diff($kpiIds, $visible)) > 0, 422, 'You can only link KPIs you can see.');
            if ($i) {
                $current = DB::table('initiative_kpi')->where('initiative_id', $i->id)->pluck('kpi_id')->all();
                $seen    = $this->access->scopeByDepartment(Kpi::withoutGlobalScopes()->where('company_id', $cid)->whereIn('id', $current), $u)->pluck('id')->all();
                $kpiIds  = array_values(array_unique(array_merge($kpiIds, array_diff($current, $seen))));
            }
        }

        return [$projectIds, $kpiIds];
    }

    private function authorizeWrite(Request $request): void
    {
        abort_unless($request->user()->hasPermission('projects.manage'), 403, 'You do not have permission to modify this resource.');
    }

    private function isAssignee(User $u, ExecutionPlanTask $t): bool
    {
        return $t->assigned_to !== null && (int) $t->assigned_to === $u->id && $u->hasPermission('work.own');
    }

    private function authorizeTask(Request $request, Initiative $i): void
    {
        abort_unless($this->access->canWorkOn($request->user(), $i->department_id, $i->owner_id), 403, 'You do not have permission to change this initiative\'s plan.');
    }

    /** Loads the linked projects and KPIs for a batch of initiatives in two queries. */
    private function shapeMany(Collection $items): array
    {
        $ids      = $items->pluck('id');
        $me       = request()->user();
        $isViewer = ! ($me?->hasPermission('work.own') ?? false); // read-only: no work.own
        $view     = $me ? $this->access->viewIds($me) : null; // null = unrestricted
        $projects = DB::table('initiative_project as ip')->join('projects as p', 'p.id', '=', 'ip.project_id')->leftJoin('departments as d', 'd.id', '=', 'p.department_id')
            ->whereIn('ip.initiative_id', $ids)
            ->when($view !== null, fn ($q) => $q->where(fn ($w) => $w->whereIn('p.department_id', $view)->orWhere('p.owner_id', $me->id)))
            ->orderBy('ip.id')
            ->get(['ip.initiative_id', 'p.id', 'p.code', 'p.name', 'p.name_ar', 'p.completion_pct', 'd.name as department_name', 'd.name_ar as department_name_ar'])->groupBy('initiative_id');
        $kpis = DB::table('initiative_kpi as ik')->join('kpis as k', 'k.id', '=', 'ik.kpi_id')
            ->whereIn('ik.initiative_id', $ids)
            ->when($view !== null, fn ($q) => $q->whereIn('k.department_id', $view))
            ->orderBy('ik.id')->get(['ik.initiative_id', 'k.id', 'k.code', 'k.name', 'k.name_ar'])->groupBy('initiative_id');

        return $items->map(fn (Initiative $i) => array_merge(
            $i->only(['id', 'department_id', 'strategic_objective_id', 'owner_id', 'code', 'name', 'name_ar', 'description', 'description_ar', 'status', 'year']),
            [
                'planned_start_date' => $i->planned_start_date?->toDateString(), 'planned_end_date' => $i->planned_end_date?->toDateString(),
                'completion_pct' => (float) $i->completion_pct, 'is_on_timeline' => (bool) $i->is_on_timeline,
                'department' => $i->department?->only(['id', 'name', 'name_ar']),
                'objective' => $i->objective?->only(['id', 'code', 'name', 'name_ar']),
                'owner' => $i->owner?->only(['id', 'name']),
                'projects' => ($projects[$i->id] ?? collect())->map(fn ($p) => [
                    'id' => $p->id, 'code' => $p->code, 'name' => $p->name, 'name_ar' => $p->name_ar, 'completion_pct' => (float) $p->completion_pct,
                    'department_name' => $p->department_name, 'department_name_ar' => $p->department_name_ar,
                ])->values()->all(),
                'kpis' => ($kpis[$i->id] ?? collect())->map(fn ($k) => ['id' => $k->id, 'code' => $k->code, 'name' => $k->name, 'name_ar' => $k->name_ar])->values()->all(),
                'tasks' => $i->tasks->map(fn ($t) => [
                    'id' => $t->id, 'task_name' => $t->task_name, 'task_name_ar' => $t->task_name_ar, 'due_date' => $t->due_date?->toDateString(),
                    'completion_pct' => (float) $t->completion_pct,
                    'assigned_to' => $t->assigned_to ? (int) $t->assigned_to : null, 'assignee' => $t->assignee?->only(['id', 'name']),
                    // may this viewer change the task: everything (plan editors) or just its completion (the assignee)
                    'can_update' => $me && ($this->access->canWorkOn($me, $i->department_id, $i->owner_id) || (! $isViewer && $t->assigned_to !== null && (int) $t->assigned_to === $me->id)),
                    // 'overdue' is worked out when read, so it never goes stale.
                    'status' => $t->status !== 'completed' && $t->due_date && $t->due_date->isPast() && ! $t->due_date->isToday() ? 'overdue' : $t->status,
                ])->values()->all(),
            ]
        ))->values()->all();
    }
}
