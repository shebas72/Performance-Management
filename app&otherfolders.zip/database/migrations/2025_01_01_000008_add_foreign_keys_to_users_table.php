<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Now companies and departments exist — safe to add constraints
            $table->foreign('company_id')
                  ->references('id')->on('companies')
                  ->nullOnDelete();

            $table->foreign('department_id')
                  ->references('id')->on('departments')
                  ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropForeign(['company_id']);
            $table->dropForeign(['department_id']);
        });
    }
};
