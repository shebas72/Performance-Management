<?php

namespace App\Http\Controllers\Api\V1;

use App\Models\Kpi;
use App\Services\AccessScope;
use App\Services\KpiChangeLogger;
use App\Services\Limits;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class KpiController extends CompanyResourceController
{
    protected string $model = Kpi::class;

    public function __construct(private KpiChangeLogger $changes, private AccessScope $access, private Limits $limits) {}

    protected array $searchable = ['name', 'name_ar', 'code'];
    protected array $filterable = [
        'strategic_objective_id', 'bsc_perspective_id', 'department_id',
        'owner_id', 'type', 'frequency', 'direction', 'year',
    ];

    protected function rules(): array
    {
        return [
            'strategic_objective_id' => ['nullable', $this->existsInCompany('strategic_objectives')],
            'bsc_perspective_id'     => ['nullable', $this->existsInCompany('bsc_perspectives')],
            'department_id'          => ['nullable', $this->existsInCompany('departments')],
            'owner_id'               => ['nullable', $this->existsInCompany('users')],

            'code'                   => ['required', 'string', 'max:255'],
            'name'                   => ['required', 'string', 'max:255'],
            'name_ar'                => ['nullable', 'string', 'max:255'],
            'description'            => ['nullable', 'string'],
            'description_ar'         => ['nullable', 'string'],
            'year'                   => ['required', 'integer', 'min:2000', 'max:2100'],

            // These columns have DB defaults, so they are only validated when sent.
            'type'                   => ['sometimes', 'in:strategic,operational'],
            'frequency'              => ['sometimes', 'in:monthly,quarterly,yearly'],
            'direction'              => ['sometimes', 'in:higher_is_better,lower_is_better'],
            'value_type'             => ['sometimes', 'in:percentage,number,currency,ratio'],
            'weight'                 => ['sometimes', 'numeric', 'min:0', 'max:100'],
            'threshold_red'          => ['sometimes', 'numeric', 'min:0', 'max:100'],
            'threshold_yellow'       => ['sometimes', 'numeric', 'min:0', 'max:100'],
            'has_recovery_target'    => ['sometimes', 'boolean'],
            'is_active'              => ['sometimes', 'boolean'],

            'unit'                   => ['nullable', 'string', 'max:50'],
            'annual_target'          => ['nullable', 'numeric'],
        ];
    }

    protected function scoped($query)
    {
        return $this->access->scopeByDepartment($query, Auth::user());
    }

    protected function beforeCreate(array $data): array
    {
        $this->guard($data['department_id'] ?? null);
        // A new KPI is active unless said otherwise; inactive ones do not use a plan seat.
        if ($data['is_active'] ?? true) $this->limits->assertCanAdd((int) Auth::user()->company_id, 'kpis');
        $data['created_by'] = Auth::id();

        return $data;
    }

    protected function beforeUpdate($record, array $data): array
    {
        $this->guard($record->department_id);
        if (array_key_exists('department_id', $data)) $this->guard($data['department_id']);
        // Switching a KPI back on takes a plan seat again.
        if (! $record->is_active && ($data['is_active'] ?? false)) $this->limits->assertCanAdd((int) $record->company_id, 'kpis');

        return $data;
    }

    /** Counts taken before the delete, written to the deletion record after it succeeds. */
    private array $deletedCounts = [];

    protected function beforeDelete($record): void
    {
        $this->guard($record->department_id);
        $this->deletedCounts = $this->changes->deletionCounts($record);
    }

    protected function afterDelete($record): void
    {
        $this->changes->kpiDeleted($record, $this->deletedCounts, Auth::id());
    }

    private function guard($departmentId): void
    {
        abort_unless(
            $this->access->canEdit(Auth::user(), $departmentId === null ? null : (int) $departmentId),
            403,
            'You can only manage KPIs in your own departments.'
        );
    }

    protected function afterCreate($record): void
    {
        $this->changes->kpiCreated($record, Auth::id());
    }

    protected function afterUpdate($record, array $before): void
    {
        $this->changes->kpiUpdated($record, $before, Auth::id());

        // Open corrective proposals follow the KPI to its new department (finished ones stay where they were as history).
        if ($record->wasChanged('department_id')) {
            DB::table('corrective_proposals')
                ->where('company_id', $record->company_id)->where('kpi_id', $record->id)
                ->whereIn('status', ['pending', 'in_progress'])
                ->update(['department_id' => $record->department_id, 'updated_at' => now()]);
        }
    }
}