<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\V1\Concerns\ResolvesTenant;
use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\Invitation;
use App\Models\User;
use App\Services\Limits;
use App\Services\RolePermissions;
use App\Support\Permissions;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;

/**
 * A tenant's team: users, their roles, and invitations. Everything except the two public invitation endpoints is admin-only.
 * Add frontend_url to config/app.php: 'frontend_url' => env('FRONTEND_URL', 'http://localhost:5173').
 */
class TeamController extends Controller
{
    use ResolvesTenant;

    private const INVITE_DAYS = 7;

    public function __construct(private Limits $limits) {}

    private function roles(): RolePermissions
    {
        return RolePermissions::resolve();
    }

    /* ---- users ---- */

    public function users(Request $request)
    {
        $cid = $this->requireAdmin($request);
        $users = User::where('company_id', $cid)->where('is_super_admin', false)->with('roles:id,name')->orderBy('name')->get();
        $links = DB::table('department_user')->whereIn('user_id', $users->pluck('id'))->get()->groupBy('user_id');

        return response()->json([
            'data' => $users->map(fn ($u) => $this->shapeUser($u, $links->get($u->id, collect())))->values(),
            'meta' => ['roles' => $this->roles()->keys($cid), 'role_labels' => $this->roles()->labels($cid), 'me' => $request->user()->id],
        ]);
    }

    public function updateUser(Request $request, int $id)
    {
        $cid  = $this->requireAdmin($request);
        $user = User::where('company_id', $cid)->where('is_super_admin', false)->findOrFail($id);
        $data = $request->validate([
            'role' => ['sometimes', Rule::in($this->roles()->keys($cid))], 'is_active' => ['sometimes', 'boolean'], 'name' => ['sometimes', 'string', 'max:255'],
            'email' => ['sometimes', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
            'password' => ['sometimes', 'string', 'min:8'],
        ] + $this->accessRules($cid));
        if (($data['is_active'] ?? false) && ! (bool) ($user->is_active ?? true)) $this->limits->assertCanAdd($cid, 'users'); // reactivating takes a seat
        abort_if(isset($data['password']) && $user->id === $request->user()->id, 422, 'Change your own password from your profile.');

        $losesAdmin = $user->hasRole('admin') && ((isset($data['role']) && $data['role'] !== 'admin') || (isset($data['is_active']) && ! $data['is_active']));
        if ($user->id === $request->user()->id && (isset($data['role']) || isset($data['is_active']))) {
            abort(422, 'You cannot change your own role or deactivate your own account.');
        }
        if ($losesAdmin) {
            $others = User::where('company_id', $cid)->where('is_active', true)->where('id', '!=', $user->id)->role('admin')->count();
            abort_if($others < 1, 422, 'The company must keep at least one active admin.');
        }

        DB::transaction(function () use ($user, $data) {
            if (isset($data['name'])) $user->forceFill(['name' => $data['name']]);
            if (isset($data['email'])) $user->forceFill(['email' => Str::lower($data['email'])]);
            if (isset($data['password'])) $user->forceFill(['password' => Hash::make($data['password'])]);
            if (isset($data['is_active'])) $user->forceFill(['is_active' => $data['is_active']]);
            $user->save();
            if (isset($data['role'])) $this->assignRole($user, $data['role']);
            $this->applyAccess($user, $data);
            if (isset($data['password']) || (isset($data['is_active']) && ! $data['is_active'])) {
                $user->tokens()->delete(); // signs them out everywhere
            }
        });

        return response()->json(['data' => $this->shapeUser($user->fresh('roles'))]);
    }

    /**
     * Admin adds a user directly (no invitation). With no password given, a temporary one is generated and returned once.
     * Counts against the plan's user limit.
     */
    public function createUser(Request $request)
    {
        $cid  = $this->requireAdmin($request);
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'], 'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'role' => ['required', Rule::in($this->roles()->keys($cid))], 'password' => ['nullable', 'string', 'min:8'],
        ] + $this->accessRules($cid));
        $this->limits->assertCanAdd($cid, 'users');
        $plain = $data['password'] ?? Str::password(12, symbols: false);

        $user = DB::transaction(function () use ($cid, $data, $plain) {
            $user = new User();
            $user->forceFill([
                'company_id' => $cid, 'name' => $data['name'], 'email' => Str::lower($data['email']),
                'password' => Hash::make($plain), 'email_verified_at' => now(), 'is_active' => true,
            ])->save();
            $this->assignRole($user, $data['role']);
            $this->applyAccess($user, $data);

            return $user;
        });

        return response()->json(['data' => $this->shapeUser($user->load('roles')) + ['temporary_password' => isset($data['password']) ? null : $plain]], 201);
    }

    /** Names of the active people in the company, for owner/manager pickers. Any signed-in member may read it. */
    public function lookup(Request $request)
    {
        $cid   = $this->companyId($request);
        $users = User::where('company_id', $cid)->where('is_super_admin', false)->where('is_active', true)
            ->with('roles:id,name')->orderBy('name')->get(['id', 'name']);

        return response()->json(['data' => $users->map(fn ($u) => ['id' => $u->id, 'name' => $u->name, 'role' => $this->roles()->keyFor($u)])->values()]);
    }

    /* ---- invitations ---- */

    public function invitations(Request $request)
    {
        $cid = $this->requireAdmin($request);
        $rows = Invitation::with('inviter:id,name')->where('company_id', $cid)->pending()->latest('id')->get();

        return response()->json(['data' => $rows->map(fn ($i) => $this->shapeInvitation($i))->values()]);
    }

    public function invite(Request $request)
    {
        $cid  = $this->requireAdmin($request);
        $data = $request->validate(['email' => ['required', 'email', 'max:255'], 'role' => ['required', Rule::in($this->roles()->keys($cid))]] + $this->accessRules($cid));
        $email = Str::lower($data['email']);

        if (! empty($data['manager_id'])) {
            abort_unless(User::where('company_id', $cid)->where('is_active', true)->find($data['manager_id'])?->hasPermission('team_report.lead'), 422, 'The manager must be an active person who can lead a team.');
        }
        $isAdminRole = $data['role'] === 'admin'; // admins always see everything, so no scope or departments are stored

        abort_if(User::where('email', $email)->exists(), 422, 'This email address is already registered.');
        $this->limits->assertCanAdd($cid, 'users');
        abort_if(Invitation::where('company_id', $cid)->where('email', $email)->pending()->where('expires_at', '>', now())->exists(), 422, 'An invitation is already pending for this email. Resend it instead.');

        $token = Str::random(48);
        $inv   = new Invitation();
        $inv->forceFill([
            'company_id' => $cid, 'email' => $email, 'role' => $data['role'], 'token_hash' => hash('sha256', $token),
            'invited_by' => $request->user()->id, 'expires_at' => now()->addDays(self::INVITE_DAYS),
            'access_scope' => $isAdminRole ? 'all' : ($data['access_scope'] ?? 'own'),
            'manager_id' => $isAdminRole ? null : ($data['manager_id'] ?? null),
            'department_ids' => $isAdminRole ? [] : array_values($data['department_ids'] ?? []),
            'access_department_ids' => $isAdminRole ? [] : array_values($data['access_department_ids'] ?? []),
        ])->save();

        return response()->json(['data' => $this->withLink($inv, $token, $request)], 201);
    }

    /** New link and new expiry; the old link stops working. */
    public function resend(Request $request, int $id)
    {
        $cid = $this->requireAdmin($request);
        $inv = Invitation::where('company_id', $cid)->pending()->findOrFail($id);
        if ($inv->expires_at->isPast()) $this->limits->assertCanAdd($cid, 'users'); // an expired invitation held no seat
        $token = Str::random(48);
        $inv->forceFill(['token_hash' => hash('sha256', $token), 'expires_at' => now()->addDays(self::INVITE_DAYS)])->save();

        return response()->json(['data' => $this->withLink($inv, $token, $request)]);
    }

    public function revoke(Request $request, int $id)
    {
        $cid = $this->requireAdmin($request);
        Invitation::where('company_id', $cid)->pending()->findOrFail($id)->forceFill(['revoked_at' => now()])->save();

        return response()->noContent();
    }

    /* ---- public: the invited person ---- */

    public function showInvite(string $token)
    {
        $inv = $this->usable($token);

        return response()->json(['data' => ['email' => $inv->email, 'role' => $inv->role, 'role_label' => $this->roles()->label((int) $inv->company_id, $inv->role), 'company' => Company::find($inv->company_id)?->name]]);
    }

    public function accept(Request $request)
    {
        $data = $request->validate(['token' => ['required', 'string'], 'name' => ['required', 'string', 'max:255'], 'password' => ['required', 'string', 'min:8', 'confirmed']]);
        $inv  = $this->usable($data['token']);
        abort_if(User::where('email', $inv->email)->exists(), 422, 'This email address is already registered.');
        // The invitation itself already holds a seat, so only a plan that shrank below the current use blocks the accept.
        $this->limits->assertCanAdd((int) $inv->company_id, 'users', 0);

        $user = DB::transaction(function () use ($inv, $data) {
            $user = new User();
            $user->forceFill([
                'company_id' => $inv->company_id, 'name' => $data['name'], 'email' => $inv->email,
                'password' => Hash::make($data['password']), 'email_verified_at' => now(), 'is_active' => true,
            ])->save();
            $this->assignRole($user, $inv->role);
            $this->applyInvitationAccess($user, $inv);
            $inv->forceFill(['accepted_at' => now()])->save();

            return $user;
        });

        return response()->json(app(AuthController::class)->payload($user, $user->createToken('spa')->plainTextToken), 201);
    }

    /* ---- helpers ---- */

    /** Sets the user's role. Only the four built-in roles exist in Spatie (the admin one still marks a company admin for the last-admin guard). */
    private function assignRole(User $user, string $key): void
    {
        if (! in_array($key, $this->roles()->keys((int) $user->company_id), true)) $key = 'viewer'; // the role was deleted after the invitation went out

        $user->forceFill(['role_key' => $key])->save();
        if (array_key_exists($key, Permissions::SYSTEM)) {
            Role::findOrCreate($key);
            $user->syncRoles([$key]);
        } else {
            $user->syncRoles([]);
        }
        $this->roles()->flush();
    }

    private function requireAdmin(Request $request): int
    {
        abort_unless($request->user()->hasPermission('team.manage'), 403, 'You do not have permission to manage the team.');

        return $this->companyId($request);
    }

    private function usable(string $token): Invitation
    {
        $inv = Invitation::where('token_hash', hash('sha256', $token))->first();
        abort_if(! $inv || ! $inv->isUsable(), 404, 'This invitation is invalid or has expired. Ask your admin for a new one.');

        return $inv;
    }

    private function withLink(Invitation $inv, string $token, Request $request): array
    {
        $link = rtrim(config('app.frontend_url', 'http://localhost:5173'), '/').'/accept-invite?token='.$token;
        $sent = false;
        try {
            $company = Company::find($inv->company_id)?->name;
            Mail::raw("{$request->user()->name} invited you to join {$company} on the performance management system as {$inv->role}.\n\nAccept the invitation and set your password:\n{$link}\n\nThis link expires on {$inv->expires_at->toDayDateTimeString()}.",
                fn ($m) => $m->to($inv->email)->subject("You're invited to join {$company}"));
            $sent = true;
        } catch (\Throwable $e) {
            report($e); // mail not configured: the admin can still copy the link
        }

        return $this->shapeInvitation($inv->load('inviter:id,name')) + ['invite_url' => $link, 'emailed' => $sent];
    }

    /**
     * Apply what the admin chose when inviting. Departments and the manager are re-checked now, because they may have been
     * removed, deactivated or changed role during the days the invitation was pending; anything no longer valid is skipped.
     * An invitation sent before this feature has no stored choice, so the person keeps the default (scope own, no departments).
     */
    private function applyInvitationAccess(User $user, Invitation $inv): void
    {
        if ($inv->role === 'admin') return;

        $valid   = fn (?array $ids) => DB::table('departments')->where('company_id', $inv->company_id)->whereIn('id', $ids ?: [0])->pluck('id')->map(fn ($v) => (int) $v)->all();
        $manager = $inv->manager_id ? User::where('company_id', $inv->company_id)->where('is_active', true)->find($inv->manager_id) : null;

        $this->applyAccess($user, [
            'access_scope'          => in_array($inv->access_scope, ['own', 'all', 'selected'], true) ? $inv->access_scope : 'own',
            'manager_id'            => $manager?->hasPermission('team_report.lead') ? $manager->id : null,
            'department_ids'        => $valid($inv->department_ids),
            'access_department_ids' => $valid($inv->access_department_ids),
        ]);
    }

    private function accessRules(int $cid): array
    {
        $dept = Rule::exists('departments', 'id')->where('company_id', $cid);

        return [
            'access_scope'          => ['sometimes', Rule::in(['own', 'all', 'selected'])],
            'manager_id'            => ['sometimes', 'nullable', 'integer', Rule::exists('users', 'id')->where('company_id', $cid)],
            'department_ids'        => ['sometimes', 'array'],
            'department_ids.*'      => ['integer', 'distinct', $dept],
            'access_department_ids' => ['sometimes', 'array'],
            'access_department_ids.*' => ['integer', 'distinct', $dept],
        ];
    }

    /** Scope, manager and department links. Only the keys that were sent are changed. */
    private function applyAccess(User $user, array $data): void
    {
        $fill = [];
        if (isset($data['access_scope'])) $fill['access_scope'] = $data['access_scope'];
        if (array_key_exists('manager_id', $data)) {
            if ($data['manager_id']) {
                abort_if((int) $data['manager_id'] === $user->id, 422, 'A user cannot be their own manager.');
                abort_unless(User::find($data['manager_id'])?->hasPermission('team_report.lead'), 422, 'The manager must have a role that can lead a team.');
            }
            $fill['manager_id'] = $data['manager_id'] ?: null;
        }
        if ($fill) $user->forceFill($fill)->save();

        foreach (['department_ids' => 'member', 'access_department_ids' => 'access'] as $key => $kind) {
            if (! array_key_exists($key, $data)) continue;
            DB::table('department_user')->where('user_id', $user->id)->where('kind', $kind)->delete();
            $rows = collect($data[$key])->unique()->map(fn ($d) => ['user_id' => $user->id, 'department_id' => (int) $d, 'kind' => $kind])->values()->all();
            if ($rows) DB::table('department_user')->insert($rows);
        }
    }

    private function shapeUser(User $u, $links = null): array
    {
        $links ??= DB::table('department_user')->where('user_id', $u->id)->get();
        $ids = fn (string $kind) => $links->where('kind', $kind)->pluck('department_id')->map(fn ($v) => (int) $v)->values();

        return [
            'id' => $u->id, 'name' => $u->name, 'email' => $u->email, 'role' => $this->roles()->keyFor($u), 'is_lead' => $u->hasPermission('team_report.lead'),
            'is_active' => (bool) ($u->is_active ?? true), 'created_at' => $u->created_at?->toDateString(),
            'access_scope' => $u->access_scope ?? 'all', 'manager_id' => $u->manager_id ?? null,
            'department_ids' => $ids('member'), 'access_department_ids' => $ids('access'),
        ];
    }

    private function shapeInvitation(Invitation $i): array
    {
        return [
            'id' => $i->id, 'email' => $i->email, 'role' => $i->role, 'expires_at' => $i->expires_at->toDateString(), 'expired' => $i->expires_at->isPast(), 'invited_by' => $i->inviter?->name,
            'access_scope' => $i->access_scope ?? 'own', 'manager_id' => $i->manager_id,
            'department_ids' => array_map('intval', $i->department_ids ?? []), 'access_department_ids' => array_map('intval', $i->access_department_ids ?? []),
        ];
    }
}
